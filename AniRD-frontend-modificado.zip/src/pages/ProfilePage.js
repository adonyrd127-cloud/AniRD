import { authService } from '../services/auth.service.js';
import { dbService, db } from '../services/db.js';
import { spatialNavigation } from '../services/spatialNavigation.js';
import '../components/AnimeCard.js';

export default class ProfilePage {
  constructor(params) {
    this.params = params;
    this.user = authService.getUser();
    this.activeTab = 'list'; // 'list', 'favs', 'settings'
    this.followedAnimes = [];
    this.favoriteAnimes = [];
    this.stats = { favs: 0, list: 0, epis: 0 };
  }

  async render() {
    if (!this.user) {
      window.location.href = '/auth';
      return document.createElement('div');
    }

    this.followedAnimes = await db.following.toArray();
    this.favoriteAnimes = await db.favorites.toArray();
    this.stats = {
      favs: this.favoriteAnimes.length,
      list: this.followedAnimes.length,
      epis: await db.history.count()
    };

    const container = document.createElement('div');
    container.className = 'page-container';
    
    container.innerHTML = `
      <style>
        .profile-hero-v5 {
          height: 350px;
          position: relative;
          background: #0a0a0a;
          display: flex;
          align-items: flex-end;
          padding: 0 5% 40px;
          overflow: hidden;
          border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        .profile-hero-v5::before {
          content: '';
          position: absolute;
          inset: 0;
          background: linear-gradient(45deg, #ff0000 0%, #330000 100%);
          opacity: 0.15;
          filter: blur(50px);
        }
        .user-meta-v5 {
          position: relative;
          z-index: 10;
          display: flex;
          align-items: center;
          gap: 30px;
          width: 100%;
        }
        .avatar-v5 {
          width: 120px; height: 120px;
          background: var(--accent);
          border-radius: 35px;
          display: flex; align-items: center; justify-content: center;
          font-size: 48px; font-weight: 900; color: white;
          box-shadow: 0 20px 40px rgba(255,0,0,0.3);
          border: 4px solid rgba(255,255,255,0.1);
        }
        .user-info-v5 h1 { font-family: 'Outfit', sans-serif; font-size: 2.5rem; font-weight: 900; margin: 0; }
        .user-info-v5 p { color: var(--text-muted); font-size: 12px; text-transform: uppercase; letter-spacing: 2px; font-weight: 700; }

        .stats-row-v5 { display: flex; gap: 20px; margin-left: auto; }
        .stat-chip-v5 {
          background: rgba(255,255,255,0.05);
          backdrop-filter: blur(10px);
          padding: 15px 25px;
          border-radius: 20px;
          text-align: center;
          border: 1px solid rgba(255,255,255,0.08);
        }
        .stat-chip-v5 b { display: block; font-size: 20px; color: white; }
        .stat-chip-v5 span { font-size: 10px; color: var(--text-muted); font-weight: 800; }

        .profile-tabs-v5 {
          display: flex;
          gap: 40px;
          padding: 0 5%;
          margin-top: -1px;
          border-bottom: 1px solid rgba(255,255,255,0.05);
          background: rgba(5,5,5,0.5);
          backdrop-filter: blur(20px);
        }
        .tab-btn-v5 {
          padding: 20px 0;
          background: none; border: none;
          color: var(--text-muted);
          font-weight: 800; font-size: 13px;
          cursor: pointer;
          position: relative;
          transition: color 0.3s;
        }
        .tab-btn-v5.active { color: white; }
        .tab-btn-v5.active::after {
          content: ''; position: absolute; bottom: 0; left: 0; right: 0;
          height: 3px; background: var(--accent); border-radius: 10px 10px 0 0;
        }

        .tab-content-v5 { padding: 40px 5% 100px; }
        .grid-v5 { display: grid; grid-template-columns: repeat(auto-fill, minmax(185px, 1fr)); gap: 30px; }

        .settings-card-v5 {
          max-width: 600px;
          background: rgba(255,255,255,0.03);
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 30px;
          padding: 40px;
        }

        .sync-btn-mobile {
          display: none;
        }

        @media (max-width: 900px) {
          .profile-hero-v5 { height: auto; padding: 100px 5% 40px; }
          .user-meta-v5 { flex-direction: column; text-align: center; }
          .stats-row-v5 { margin: 20px auto 0; }
          .profile-tabs-v5 { gap: 20px; justify-content: center; }
        }
      </style>

      <div class="profile-hero-v5">
        <div class="user-meta-v5">
          <div class="avatar-v5">${this.user.username.charAt(0).toUpperCase()}</div>
          <div class="user-info-v5">
            <p>Panel de Usuario</p>
            <h1>${this.user.username}</h1>
          </div>
          <div class="stats-row-v5">
            <div class="stat-chip-v5"><b>${this.stats.list}</b><span>SIGUIENDO</span></div>
            <div class="stat-chip-v5"><b>${this.stats.favs}</b><span>FAVORITOS</span></div>
            <div class="stat-chip-v5"><b>${this.stats.epis}</b><span>EPISODIOS</span></div>
          </div>
        </div>
      </div>

      <nav class="profile-tabs-v5">
        <button class="tab-btn-v5 active" data-tab="list">MI LISTA</button>
        <button class="tab-btn-v5" data-tab="favs">FAVORITOS</button>
        <button class="tab-btn-v5" data-tab="my-lists">MIS LISTAS</button>
        <button class="tab-btn-v5" data-tab="settings">AJUSTES</button>
      </nav>

      <div class="tab-content-v5" id="profile-tab-content">
        <!-- Contenido dinámico -->
      </div>
      
      <div class="sync-btn-mobile" id="sync-btn-profile-mobile">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: var(--accent-secondary);">
            <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>
        </svg>
        Sincronizar con Orange Pi
      </div>
    `;

    return container;
  }

  async afterRender() {
    const tabContent = document.getElementById('profile-tab-content');
    const tabs = document.querySelectorAll('.tab-btn-v5');

    const renderTab = async (tabName) => {
      this.activeTab = tabName;
      tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === tabName));

      if (tabName === 'list') {
        tabContent.innerHTML = `<div class="grid-v5" id="grid-follow"></div>`;
        const grid = document.getElementById('grid-follow');
        
        function getNextEpisodeCountdown(broadcast) {
          if (!broadcast || !broadcast.day || !broadcast.time || !broadcast.timezone) return null;
          const days = { 'Sundays': 0, 'Mondays': 1, 'Tuesdays': 2, 'Wednesdays': 3, 'Thursdays': 4, 'Fridays': 5, 'Saturdays': 6 };
          const targetDay = days[broadcast.day];
          if (targetDay === undefined) return null;

          const [hours, minutes] = broadcast.time.split(':').map(Number);
          const tokyoNow = new Date(new Date().toLocaleString("en-US", {timeZone: broadcast.timezone}));
          
          let targetDate = new Date(tokyoNow);
          targetDate.setHours(hours, minutes, 0, 0);

          let daysToAdd = targetDay - tokyoNow.getDay();
          if (daysToAdd < 0 || (daysToAdd === 0 && targetDate < tokyoNow)) {
            daysToAdd += 7;
          }
          targetDate.setDate(targetDate.getDate() + daysToAdd);

          const diffMs = targetDate - tokyoNow;
          if (diffMs <= 0) return null;

          const d = Math.floor(diffMs / (1000 * 60 * 60 * 24));
          const h = Math.floor((diffMs / (1000 * 60 * 60)) % 24);
          
          if (d > 0) return `${d}d ${h}h para nuevo cap.`;
          if (h > 0) return `${h}h para nuevo cap.`;
          return `¡Nuevo cap en breve!`;
        }

        if (this.followedAnimes.length > 0) {
          this.followedAnimes.forEach(a => {
            const card = document.createElement('anime-card');
            const initialData = { mal_id: a.animeId, title: a.title, images: { jpg: { large_image_url: a.cover } } };
            card.data = initialData;
            grid.appendChild(card);

            // Cargar episodio actual e info en paralelo
            Promise.all([
              import('../services/db.js').then(({ db }) => db.history.where('animeId').equals(String(a.animeId)).reverse().sortBy('timestamp')),
              import('../services/api.js').then(({ apiService }) => apiService.getAnimeInfo(a.animeId))
            ]).then(([history, res]) => {
              let updatedData = { ...initialData };
              
              if (history && history.length > 0) {
                updatedData.currentEpisode = history[0].episodeId;
              }

              if (res && res.data) {
                if (res.data.status === 'Currently Airing') {
                  const countdown = getNextEpisodeCountdown(res.data.broadcast);
                  if (countdown) updatedData.nextEpisodeText = countdown;
                  updatedData.status = 'EN EMISIÓN';
                } else if (res.data.status === 'Finished Airing') {
                  updatedData.status = 'FINALIZADO';
                }
              }
              
              card.data = updatedData;
            });
          });
        } else { tabContent.innerHTML = '<p style="color:var(--text-muted)">Tu lista de seguimiento está vacía.</p>'; }
      }

      if (tabName === 'favs') {
        tabContent.innerHTML = `<div class="grid-v5" id="grid-favs"></div>`;
        const grid = document.getElementById('grid-favs');
        if (this.favoriteAnimes.length > 0) {
          this.favoriteAnimes.forEach(a => {
            const card = document.createElement('anime-card');
            const initialData = { mal_id: a.animeId, title: a.title, images: { jpg: { large_image_url: a.cover } }, status: a.status, broadcast: a.broadcast };
            card.data = initialData;
            grid.appendChild(card);
            
            import('../services/api.js').then(({ apiService }) => {
              apiService.getAnimeInfo(a.animeId).then(res => {
                if (res && res.data) {
                  card.data = {
                    ...initialData,
                    status: res.data.status,
                    broadcast: res.data.broadcast,
                    episodes: res.data.episodes,
                    score: res.data.score
                  };
                }
              });
            });
          });
        } else { tabContent.innerHTML = '<p style="color:var(--text-muted)">Aún no tienes favoritos.</p>'; }
      }

      if (tabName === 'my-lists') {
        const allLists = await db.lists.orderBy('createdAt').reverse().toArray();
        tabContent.innerHTML = `
          <div style="display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 24px;">
            ${allLists.map(list => `
              <a href="/lists" data-link class="glass-card-hover" style="display: flex; align-items: center; gap: 14px; padding: 16px 20px; text-decoration: none; min-width: 200px; flex: 1; max-width: 300px;">
                <div style="width: 42px; height: 42px; border-radius: 12px; background: rgba(229,9,20,0.1); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#e50914" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
                </div>
                <div>
                  <div style="color: white; font-size: 14px; font-weight: 700; font-family: 'Outfit';">${list.name}</div>
                  <div style="color: var(--text-muted); font-size: 11px; font-weight: 600;">${(list.animeIds || []).length} anime${(list.animeIds || []).length !== 1 ? 's' : ''}</div>
                </div>
              </a>
            `).join('')}
          </div>
          <a href="/lists" data-link class="btn-v4-primary" style="display: inline-flex; align-items: center; gap: 8px; text-decoration: none; padding: 12px 24px; border-radius: 14px;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Gestionar Listas
          </a>
        `;
      }

      if (tabName === 'settings') {
        const theme = await dbService.getSetting('theme', 'dark');
        const audio = await dbService.getSetting('audio_pref', 'sub');
        tabContent.innerHTML = `
          <div class="settings-card-v5 page-enter">
            <h3 style="margin-bottom:30px; font-family:'Outfit'">Configuración Premium</h3>
            <div class="settings-item-v4">
              <label>Audio por defecto</label>
              <select id="audio-pref" class="select-v4">
                <option value="sub" ${audio === 'sub' ? 'selected' : ''}>Subtitulado (Japonés)</option>
                <option value="dub" ${audio === 'dub' ? 'selected' : ''}>Latino (Doblaje)</option>
              </select>
            </div>
            <div class="settings-item-v4">
              <label>Tema visual</label>
              <select id="theme-pref" class="select-v4">
                <option value="dark" ${theme === 'dark' ? 'selected' : ''}>Modo Oscuro</option>
                <option value="light" ${theme === 'light' ? 'selected' : ''}>Modo Claro</option>
              </select>
            </div>
            <div class="settings-item-v4">
              <label>Modo Smart TV (Control D-Pad)</label>
              <select id="tv-mode-pref" class="select-v4">
                <option value="off" ${localStorage.getItem('tvMode') !== 'true' ? 'selected' : ''}>Apagado (PC / Móvil)</option>
                <option value="on" ${localStorage.getItem('tvMode') === 'true' ? 'selected' : ''}>Encendido (Modo TV)</option>
              </select>
            </div>
            <hr style="border:none; border-top:1px solid rgba(255,255,255,0.05); margin:30px 0">
            <div style="display:flex; gap:15px; flex-wrap:wrap;">
              <button id="sync-btn" class="btn-v4-primary" style="flex:1; min-width:140px;">Sincronizar Datos</button>
              <button id="reset-db-btn" class="btn-v4-secondary" style="flex:1; min-width:140px; background:rgba(255,165,0,0.1); color:#ffa500; border-color:rgba(255,165,0,0.2)">Restablecer Local</button>
              <button id="logout-btn" class="btn-v4-secondary" style="flex:1; min-width:140px; background:rgba(255,0,0,0.1); color:#ff4444">Cerrar Sesión</button>
            </div>
          </div>
        `;

        // Eventos de ajustes
        document.getElementById('audio-pref').addEventListener('change', async (e) => await dbService.setSetting('audio_pref', e.target.value));
        document.getElementById('theme-pref').addEventListener('change', async (e) => {
          const t = e.target.value;
          await dbService.setSetting('theme', t);
          document.body.classList.toggle('light-theme', t === 'light');
        });
        document.getElementById('tv-mode-pref').addEventListener('change', (e) => {
          const active = e.target.value === 'on';
          if (active) {
            spatialNavigation.init();
          } else {
            spatialNavigation.destroy();
          }
          
          const headerToggleBtn = document.getElementById('header-tv-toggle');
          if (headerToggleBtn) {
            if (active) {
              headerToggleBtn.classList.add('active');
              headerToggleBtn.style.background = 'rgba(255, 0, 85, 0.2)';
              headerToggleBtn.style.boxShadow = '0 0 15px rgba(255, 0, 85, 0.4)';
              headerToggleBtn.style.border = '1px solid rgba(255, 0, 85, 0.4)';
            } else {
              headerToggleBtn.classList.remove('active');
              headerToggleBtn.style.background = 'rgba(255,255,255,0.05)';
              headerToggleBtn.style.boxShadow = 'none';
              headerToggleBtn.style.border = 'none';
            }
          }
        });
        document.getElementById('sync-btn').addEventListener('click', async (e) => {
          e.target.textContent = 'Procesando...';
          const localData = await dbService.getAllData();
          await authService.syncWithServer(localData);
          window.location.reload();
        });
        document.getElementById('reset-db-btn').addEventListener('click', async (e) => {
          if (confirm('¿Estás seguro de que deseas restablecer la base de datos local? Tu historial y favoritos se descargarán de nuevo de la nube de forma limpia.')) {
            e.target.textContent = 'Restableciendo...';
            try {
              const Dexie = (await import('dexie')).default;
              await Dexie.delete('AniRD_DB');
              window.location.reload();
            } catch (err) {
              alert('Error al restablecer la base de datos: ' + err.message);
              window.location.reload();
            }
          }
        });
        document.getElementById('logout-btn').addEventListener('click', () => authService.logout());
      }
    };

    // Click en pestañas
    tabs.forEach(tab => {
      tab.addEventListener('click', () => renderTab(tab.dataset.tab));
    });

    // Botón de sincronización móvil
    const mobileSyncBtn = document.getElementById('sync-btn-profile-mobile');
    if (mobileSyncBtn) {
      mobileSyncBtn.addEventListener('click', async () => {
        const originalHTML = mobileSyncBtn.innerHTML;
        mobileSyncBtn.innerHTML = `Sincronizando...`;
        try {
          const localData = await dbService.getAllData();
          await authService.syncWithServer(localData);
          mobileSyncBtn.innerHTML = `¡Sincronizado con éxito!`;
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        } catch (err) {
          mobileSyncBtn.innerHTML = `Error: ${err.message}`;
          setTimeout(() => {
            mobileSyncBtn.innerHTML = originalHTML;
          }, 3000);
        }
      });
    }

    // Render inicial
    await renderTab('list');
  }
}
